﻿This is the folder where you should put MVC views.
